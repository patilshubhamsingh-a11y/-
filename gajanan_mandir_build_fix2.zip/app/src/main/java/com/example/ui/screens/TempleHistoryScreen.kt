package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.model.TempleHistorySection
import com.example.ui.components.DevotionalTopAppBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TempleHistoryScreen(
    historySections: List<TempleHistorySection>,
    onNavigateBack: () -> Unit
) {
    Scaffold(
        topBar = { DevotionalTopAppBar(title = "मंदिराचा इतिहास", canNavigateBack = true, onNavigateBack = onNavigateBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            historySections.forEach { section ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(section.title, style = MaterialTheme.typography.titleLarge)
                        if (section.subtitle.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(section.subtitle, style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(section.content, style = MaterialTheme.typography.bodyLarge)
                        if (section.highlight.isNotBlank()) {
                            Spacer(Modifier.height(10.dp))
                            Text(section.highlight, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}
