package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.ui.components.DevotionalTopAppBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TempleLocationScreen(onNavigateBack: () -> Unit) {
    val context = LocalContext.current
    val mapUri = Uri.parse("geo:0,0?q=Shri Sant Gajanan Maharaj Mandir Ghirni, Malkapur, Buldhana, Maharashtra")
    Scaffold(
        topBar = { DevotionalTopAppBar(title = "मंदिराचे ठिकाण", canNavigateBack = true, onNavigateBack = onNavigateBack) }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("श्री संत गजानन महाराज मंदिर घिर्णी", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(8.dp))
                    Text("घिर्णी, ता. मलकापूर, जि. बुलढाणा, महाराष्ट्र")
                }
            }
            Button(
                onClick = {
                    context.startActivity(Intent(Intent.ACTION_VIEW, mapUri))
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Google Maps मध्ये मार्ग पहा") }
        }
    }
}
